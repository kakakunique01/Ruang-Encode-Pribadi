export interface User {
  username: string
  password: string
  role: "admin" | "user" | "kang"
  level?: EncryptionLevel
  displayName?: string
}

export interface Note {
  id: string
  title: string
  content: string
  createdAt: string
  updatedAt: string
  deletedAt?: string
  encryptionLevel?: EncryptionLevel
}

export type EncryptionLevel = 0 | 1 | 2 | 3 | "pro"

export const ENCRYPTION_LEVELS = {
  0: "Level 0: Aksara dan konsonan terpisah (K/V)",
  1: "Level 1: Konsonan + vokal (KV)",
  2: "Level 2: Vokal + konsonan (VK)",
  3: "Level 3: Vokal + vokal &/ KyV",
  pro: "Level Pro: Urutan sistem 0-3-1-2-0",
} as const

export interface AksaraToken {
  text: string
  level: 0 | 1 | 2 | 3
  imageUrl?: string
}

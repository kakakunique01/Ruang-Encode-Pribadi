import type { EncryptionLevel, AksaraToken } from "./types"

const aksaraMap: Record<string, { level: 0 | 1 | 2 | 3; imageUrl: string }> = {
  du: { level: 1, imageUrl: "/aksara/du.png" },
  // Aksara level 0 dan lainnya akan ditambahkan nanti
}

function isVowel(char: string): boolean {
  return "aiueoAIUEO".includes(char)
}

function isConsonant(char: string): boolean {
  return /[bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]/.test(char)
}

export function tokenizeText(text: string, userLevel?: EncryptionLevel): AksaraToken[] {
  const level = userLevel ?? 0
  console.log("[v0] tokenizeText called with userLevel:", userLevel, "level after fallback:", level)

  if (level === "pro") {
    console.log("[v0] Using tokenizeWithAllLevels for Pro user")
    return tokenizeWithAllLevels(text)
  }

  const levelNum = typeof level === "string" ? 0 : level
  console.log("[v0] Using tokenizeWithSingleLevel with level:", levelNum)
  return tokenizeWithSingleLevel(text, levelNum as 0 | 1 | 2 | 3)
}

function tokenizeWithSingleLevel(text: string, level: 0 | 1 | 2 | 3): AksaraToken[] {
  console.log("[v0] tokenizeWithSingleLevel level:", level)
  const tokens: AksaraToken[] = []
  const chars = text.split("")
  let i = 0

  while (i < chars.length) {
    let matched = false

    // Check Level 3 patterns (if user level allows)
    if (level >= 3 && i + 2 < chars.length) {
      const c1 = chars[i]
      const c2 = chars[i + 1]
      const c3 = chars[i + 2]
      const three = chars
        .slice(i, i + 3)
        .join("")
        .toLowerCase()

      if (isConsonant(c1) && c2.toLowerCase() === "y" && isVowel(c3)) {
        const aksara = aksaraMap[three]
        if (aksara && aksara.level === 3) {
          console.log("[v0] Matched Level 3 KyV:", three)
          tokens.push({
            text: chars.slice(i, i + 3).join(""),
            level: aksara.level,
            imageUrl: aksara.imageUrl,
          })
          i += 3
          matched = true
          continue
        }
      }

      if (c1.toLowerCase() === "i" && c2.toLowerCase() === "y" && isVowel(c3)) {
        const aksara = aksaraMap[three]
        if (aksara && aksara.level === 3) {
          console.log("[v0] Matched Level 3 iyV:", three)
          tokens.push({
            text: chars.slice(i, i + 3).join(""),
            level: aksara.level,
            imageUrl: aksara.imageUrl,
          })
          i += 3
          matched = true
          continue
        }
      }
    }

    // Check Level 3: VV (2 chars)
    if (!matched && level >= 3 && i + 1 < chars.length) {
      const c1 = chars[i]
      const c2 = chars[i + 1]
      const two = chars
        .slice(i, i + 2)
        .join("")
        .toLowerCase()

      if (isVowel(c1) && isVowel(c2)) {
        const aksara = aksaraMap[two]
        if (aksara && aksara.level === 3) {
          console.log("[v0] Matched Level 3 VV:", two)
          tokens.push({
            text: chars.slice(i, i + 2).join(""),
            level: aksara.level,
            imageUrl: aksara.imageUrl,
          })
          i += 2
          matched = true
          continue
        }
      }
    }

    // Check Level 1: KV
    if (!matched && level >= 1 && i + 1 < chars.length) {
      const c1 = chars[i]
      const c2 = chars[i + 1]
      const two = chars
        .slice(i, i + 2)
        .join("")
        .toLowerCase()

      if (isConsonant(c1) && isVowel(c2)) {
        const aksara = aksaraMap[two]
        console.log("[v0] Checking Level 1 KV:", two, "aksara found:", aksara)
        if (aksara && aksara.level === 1) {
          console.log("[v0] Matched Level 1 KV:", two)
          tokens.push({
            text: chars.slice(i, i + 2).join(""),
            level: aksara.level,
            imageUrl: aksara.imageUrl,
          })
          i += 2
          matched = true
          continue
        }
      }
    }

    // Check Level 2: VK
    if (!matched && level >= 2 && i + 1 < chars.length) {
      const c1 = chars[i]
      const c2 = chars[i + 1]
      const two = chars
        .slice(i, i + 2)
        .join("")
        .toLowerCase()

      if (isVowel(c1) && isConsonant(c2)) {
        const aksara = aksaraMap[two]
        if (aksara && aksara.level === 2) {
          console.log("[v0] Matched Level 2 VK:", two)
          tokens.push({
            text: chars.slice(i, i + 2).join(""),
            level: aksara.level,
            imageUrl: aksara.imageUrl,
          })
          i += 2
          matched = true
          continue
        }
      }
    }

    // Default Level 0: Single character
    if (!matched) {
      const single = chars[i].toLowerCase()
      const aksara = aksaraMap[single]
      if (aksara && aksara.level === 0) {
        console.log("[v0] Matched Level 0:", single)
        tokens.push({
          text: chars[i],
          level: 0,
          imageUrl: aksara.imageUrl,
        })
      } else {
        tokens.push({
          text: chars[i],
          level: 0,
        })
      }
      i++
    }
  }

  console.log("[v0] Final tokens:", tokens)
  return tokens
}

function tokenizeWithAllLevels(text: string): AksaraToken[] {
  const tokens: AksaraToken[] = []
  const chars = text.split("")
  let i = 0

  while (i < chars.length) {
    let matched = false

    // Priority: 0 → 3 → 1 → 2 → 0

    // Check Level 3: VV / KyV / iyV (3 chars max)
    if (i + 2 < chars.length) {
      const three = chars
        .slice(i, i + 3)
        .join("")
        .toLowerCase()
      const c1 = chars[i]
      const c2 = chars[i + 1]
      const c3 = chars[i + 2]

      // KyV pattern
      if (isConsonant(c1) && c2.toLowerCase() === "y" && isVowel(c3)) {
        const aksara = aksaraMap[three]
        tokens.push({
          text: chars.slice(i, i + 3).join(""),
          level: 3,
          imageUrl: aksara?.imageUrl,
        })
        i += 3
        matched = true
        continue
      }

      // iyV pattern
      if (c1.toLowerCase() === "i" && c2.toLowerCase() === "y" && isVowel(c3)) {
        const aksara = aksaraMap[three]
        tokens.push({
          text: chars.slice(i, i + 3).join(""),
          level: 3,
          imageUrl: aksara?.imageUrl,
        })
        i += 3
        matched = true
        continue
      }
    }

    // Check Level 3: VV (2 chars)
    if (!matched && i + 1 < chars.length) {
      const two = chars
        .slice(i, i + 2)
        .join("")
        .toLowerCase()
      const c1 = chars[i]
      const c2 = chars[i + 1]

      if (isVowel(c1) && isVowel(c2)) {
        const aksara = aksaraMap[two]
        tokens.push({
          text: chars.slice(i, i + 2).join(""),
          level: 3,
          imageUrl: aksara?.imageUrl,
        })
        i += 2
        matched = true
        continue
      }
    }

    // Check Level 1: KV
    if (!matched && i + 1 < chars.length) {
      const two = chars
        .slice(i, i + 2)
        .join("")
        .toLowerCase()
      const c1 = chars[i]
      const c2 = chars[i + 1]

      if (isConsonant(c1) && isVowel(c2)) {
        const aksara = aksaraMap[two]
        tokens.push({
          text: chars.slice(i, i + 2).join(""),
          level: 1,
          imageUrl: aksara?.imageUrl,
        })
        i += 2
        matched = true
        continue
      }
    }

    // Check Level 2: VK
    if (!matched && i + 1 < chars.length) {
      const two = chars
        .slice(i, i + 2)
        .join("")
        .toLowerCase()
      const c1 = chars[i]
      const c2 = chars[i + 1]

      if (isVowel(c1) && isConsonant(c2)) {
        const aksara = aksaraMap[two]
        tokens.push({
          text: chars.slice(i, i + 2).join(""),
          level: 2,
          imageUrl: aksara?.imageUrl,
        })
        i += 2
        matched = true
        continue
      }
    }

    // Default Level 0: Single character
    if (!matched) {
      const single = chars[i].toLowerCase()
      const aksara = aksaraMap[single]
      tokens.push({
        text: chars[i],
        level: 0,
        imageUrl: aksara?.imageUrl,
      })
      i++
    }
  }

  return tokens
}

export function encryptText(text: string, level: EncryptionLevel = 0): string {
  // Untuk backward compatibility, simpan text original
  // Actual rendering akan dilakukan di component
  return text
}

export function decryptText(text: string, level: EncryptionLevel = 0): string {
  // Untuk backward compatibility
  return text
}

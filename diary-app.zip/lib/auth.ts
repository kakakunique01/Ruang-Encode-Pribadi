import type { User } from "./types"

const STORAGE_KEY = "crypto_notes_users"
const SESSION_KEY = "crypto_notes_session"

// Default users
const defaultUsers: User[] = [
  { username: "admin", password: "123", role: "admin", level: "pro", displayName: "Administrator" },
  { username: "pemulung", password: "TPA", role: "kang", level: 0, displayName: "Pemulung" },
  { username: "user1", password: "abc", role: "user", level: 1, displayName: "Pengguna Satu" },
]

// Initialize default users
export function initializeUsers() {
  const stored = localStorage.getItem(STORAGE_KEY)
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultUsers))
  }
}

// Get all users
export function getAllUsers(): User[] {
  initializeUsers()
  const stored = localStorage.getItem(STORAGE_KEY)
  return stored ? JSON.parse(stored) : defaultUsers
}

// Authenticate user
export function authenticateUser(username: string, password: string): User | null {
  const users = getAllUsers()
  const user = users.find((u) => u.username === username && u.password === password)

  if (user) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user))
    return user
  }

  return null
}

// Get stored user session
export function getStoredUser(): User | null {
  const stored = localStorage.getItem(SESSION_KEY)
  return stored ? JSON.parse(stored) : null
}

// Clear user session
export function clearStoredUser() {
  localStorage.removeItem(SESSION_KEY)
}

// Add new user (admin only)
export function addUser(username: string, password: string, role: "user", level = 0, displayName?: string): boolean {
  const users = getAllUsers()

  if (users.find((u) => u.username === username)) {
    return false
  }

  users.push({ username, password, role, level: level as any, displayName })
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users))
  return true
}

// Update user password
export function updateUserPassword(username: string, oldPassword: string, newPassword: string): boolean {
  const users = getAllUsers()
  const userIndex = users.findIndex((u) => u.username === username && u.password === oldPassword)

  if (userIndex === -1) {
    return false
  }

  users[userIndex].password = newPassword
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users))

  const session = getStoredUser()
  if (session && session.username === username) {
    session.password = newPassword
    localStorage.setItem(SESSION_KEY, JSON.stringify(session))
  }

  return true
}

// Update user level (admin only)
export function updateUserLevel(username: string, role: "user", newPassword?: string, level?: number): boolean {
  const users = getAllUsers()
  const userIndex = users.findIndex((u) => u.username === username)

  if (userIndex === -1) {
    return false
  }

  users[userIndex].role = role
  if (newPassword) {
    users[userIndex].password = newPassword
  }
  if (level !== undefined) {
    users[userIndex].level = level as any
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users))

  return true
}

export function updateUsername(oldUsername: string, newUsername: string, password: string): boolean {
  const users = getAllUsers()
  const userIndex = users.findIndex((u) => u.username === oldUsername && u.password === password)

  if (userIndex === -1) {
    return false
  }

  if (users.find((u) => u.username === newUsername)) {
    return false
  }

  users[userIndex].username = newUsername
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users))

  const session = getStoredUser()
  if (session && session.username === oldUsername) {
    session.username = newUsername
    localStorage.setItem(SESSION_KEY, JSON.stringify(session))
  }

  return true
}

export function updateDisplayName(username: string, displayName: string): boolean {
  const users = getAllUsers()
  const userIndex = users.findIndex((u) => u.username === username)

  if (userIndex === -1) {
    return false
  }

  users[userIndex].displayName = displayName
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users))

  const session = getStoredUser()
  if (session && session.username === username) {
    session.displayName = displayName
    localStorage.setItem(SESSION_KEY, JSON.stringify(session))
  }

  return true
}

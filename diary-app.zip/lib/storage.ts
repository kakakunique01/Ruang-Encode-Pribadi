import type { Note } from "./types"

const NOTES_KEY = "crypto_notes_data"
const TRASH_KEY = "crypto_notes_trash"
const PERMANENT_KEY = "crypto_notes_permanent"

export function getNotes(username: string): Note[] {
  const stored = localStorage.getItem(`${NOTES_KEY}_${username}`)
  return stored ? JSON.parse(stored) : []
}

export function addNote(username: string, note: Omit<Note, "id" | "updatedAt">) {
  const notes = getNotes(username)
  const now = new Date().toISOString()
  const newNote: Note = {
    ...note,
    id: Date.now().toString(),
    updatedAt: now,
  }
  notes.push(newNote)
  localStorage.setItem(`${NOTES_KEY}_${username}`, JSON.stringify(notes))
  return newNote
}

export function updateNote(username: string, noteId: string, updates: Partial<Note>) {
  const notes = getNotes(username)
  const index = notes.findIndex((n) => n.id === noteId)
  if (index !== -1) {
    notes[index] = {
      ...notes[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    }
    localStorage.setItem(`${NOTES_KEY}_${username}`, JSON.stringify(notes))
    return notes[index]
  }
  return null
}

export function deleteNote(username: string, noteId: string) {
  const notes = getNotes(username)
  const trash = getTrash(username)

  const noteIndex = notes.findIndex((n) => n.id === noteId)
  if (noteIndex !== -1) {
    const deletedNote = { ...notes[noteIndex], deletedAt: new Date().toISOString() }
    trash.push(deletedNote)
    notes.splice(noteIndex, 1)

    localStorage.setItem(`${NOTES_KEY}_${username}`, JSON.stringify(notes))
    localStorage.setItem(`${TRASH_KEY}_${username}`, JSON.stringify(trash))
  }
}

export function getTrash(username: string): Note[] {
  const stored = localStorage.getItem(`${TRASH_KEY}_${username}`)
  return stored ? JSON.parse(stored) : []
}

export function restoreNote(username: string, noteId: string) {
  const notes = getNotes(username)
  const trash = getTrash(username)

  const trashIndex = trash.findIndex((n) => n.id === noteId)
  if (trashIndex !== -1) {
    const restoredNote = { ...trash[trashIndex] }
    delete restoredNote.deletedAt
    notes.push(restoredNote)
    trash.splice(trashIndex, 1)

    localStorage.setItem(`${NOTES_KEY}_${username}`, JSON.stringify(notes))
    localStorage.setItem(`${TRASH_KEY}_${username}`, JSON.stringify(trash))
  }
}

export function permanentlyDeleteNote(username: string, noteId: string) {
  const trash = getTrash(username)
  const trashIndex = trash.findIndex((n) => n.id === noteId)

  if (trashIndex !== -1) {
    const deletedNote = trash[trashIndex]
    trash.splice(trashIndex, 1)
    localStorage.setItem(`${TRASH_KEY}_${username}`, JSON.stringify(trash))

    addToPermanentTrash(username, deletedNote)
  }
}

function addToPermanentTrash(username: string, note: Note) {
  const stored = localStorage.getItem(PERMANENT_KEY)
  const permanent = stored ? JSON.parse(stored) : []
  permanent.push({ ...note, owner: username })
  localStorage.setItem(PERMANENT_KEY, JSON.stringify(permanent))
}

export function getAllPermanentlyDeleted(): (Note & { owner: string })[] {
  const stored = localStorage.getItem(PERMANENT_KEY)
  return stored ? JSON.parse(stored) : []
}

export function cleanupOldTrash() {
  const users = ["admin", "user1", "pemulung"]
  const sevenDaysAgo = new Date()
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

  users.forEach((username) => {
    const trash = getTrash(username)
    const remaining: Note[] = []

    trash.forEach((note) => {
      if (note.deletedAt) {
        const deletedDate = new Date(note.deletedAt)
        if (deletedDate > sevenDaysAgo) {
          remaining.push(note)
        } else {
          addToPermanentTrash(username, note)
        }
      }
    })

    localStorage.setItem(`${TRASH_KEY}_${username}`, JSON.stringify(remaining))
  })
}

export function permanentlyDestroyNote(noteId: string) {
  const permanent = getAllPermanentlyDeleted()
  const filtered = permanent.filter((n) => n.id !== noteId)
  localStorage.setItem(PERMANENT_KEY, JSON.stringify(filtered))
}

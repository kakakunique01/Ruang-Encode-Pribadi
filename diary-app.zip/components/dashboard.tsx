"use client"

import { useState } from "react"
import type { User } from "@/lib/auth"
import { Sidebar } from "@/components/sidebar"
import { NotesView } from "@/components/notes-view"
import { ProfileView } from "@/components/profile-view"
import { TrashView } from "@/components/trash-view"
import { AdminView } from "@/components/admin-view"
import { KangTrashView } from "@/components/kang-trash-view"

interface DashboardProps {
  user: User
  onLogout: () => void
}

export type ViewType = "notes" | "profile" | "trash" | "admin" | "kang-trash"

export function Dashboard({ user, onLogout }: DashboardProps) {
  const [currentView, setCurrentView] = useState<ViewType>("notes")
  const [selectedNoteId, setSelectedNoteId] = useState<string | undefined>()
  const [refreshKey, setRefreshKey] = useState(0)

  const handleNoteChange = () => {
    setRefreshKey((prev) => prev + 1)
  }

  const handleViewChange = (view: ViewType) => {
    setCurrentView(view)
    if (view === "notes") {
      setSelectedNoteId(undefined)
    }
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar
        key={refreshKey}
        user={user}
        currentView={currentView}
        onViewChange={handleViewChange}
        onLogout={onLogout}
        selectedNoteId={selectedNoteId}
        onSelectNote={setSelectedNoteId}
      />
      <main className="flex-1 overflow-auto">
        {currentView === "notes" && (
          <NotesView user={user} selectedNoteId={selectedNoteId} onNoteChange={handleNoteChange} />
        )}
        {currentView === "profile" && <ProfileView user={user} />}
        {currentView === "trash" && <TrashView user={user} />}
        {currentView === "admin" && <AdminView />}
        {currentView === "kang-trash" && <KangTrashView />}
      </main>
    </div>
  )
}

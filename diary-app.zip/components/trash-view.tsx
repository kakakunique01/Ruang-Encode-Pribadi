"use client"

import { useState, useEffect } from "react"
import type { User } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RotateCcw, Trash2 } from "lucide-react"
import { type Note, getTrash, restoreNote, permanentlyDeleteNote, cleanupOldTrash } from "@/lib/storage"

interface TrashViewProps {
  user: User
}

export function TrashView({ user }: TrashViewProps) {
  const [trashedNotes, setTrashedNotes] = useState<Note[]>([])
  const [isRestoreDialogOpen, setIsRestoreDialogOpen] = useState(false)
  const [selectedNote, setSelectedNote] = useState<Note | null>(null)
  const [restorePassword, setRestorePassword] = useState("")

  useEffect(() => {
    loadTrash()
    cleanupOldTrash()
  }, [user.username])

  const loadTrash = () => {
    const trash = getTrash(user.username)
    setTrashedNotes(trash)
  }

  const handleRestore = (note: Note) => {
    setSelectedNote(note)
    setRestorePassword("")
    setIsRestoreDialogOpen(true)
  }

  const confirmRestore = () => {
    if (restorePassword === user.password && selectedNote) {
      restoreNote(user.username, selectedNote.id)
      loadTrash()
      setIsRestoreDialogOpen(false)
      setSelectedNote(null)
      setRestorePassword("")
    } else {
      alert("Password salah!")
    }
  }

  const handlePermanentDelete = (note: Note) => {
    if (confirm("Hapus permanen? Data akan hilang selamanya!")) {
      permanentlyDeleteNote(user.username, note.id)
      loadTrash()
    }
  }

  const getDaysLeft = (deletedAt: string) => {
    const deleted = new Date(deletedAt)
    const now = new Date()
    const diffTime = 7 * 24 * 60 * 60 * 1000 - (now.getTime() - deleted.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return Math.max(0, diffDays)
  }

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground">Tong Sampah</h2>
          <p className="text-muted-foreground mt-1">Catatan akan otomatis terhapus setelah 7 hari</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trashedNotes.map((note) => (
            <Card key={note.id} className="hover:shadow-lg transition-shadow border-destructive/20">
              <CardHeader>
                <CardTitle className="text-lg line-clamp-1">{note.title}</CardTitle>
                <p className="text-sm text-muted-foreground">{note.date}</p>
                <p className="text-xs text-destructive">Dihapus dalam {getDaysLeft(note.deletedAt!)} hari</p>
              </CardHeader>
              <CardContent>
                <div className="font-cryptic text-sm mb-4 h-20 overflow-hidden opacity-50">{note.content}</div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleRestore(note)}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Memungut
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => handlePermanentDelete(note)}>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Hapus
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {trashedNotes.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground">Tong sampah kosong</p>
          </div>
        )}
      </div>

      {/* Restore Dialog */}
      <Dialog open={isRestoreDialogOpen} onOpenChange={setIsRestoreDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Memungut Catatan</DialogTitle>
            <DialogDescription>Masukkan password untuk memungut catatan dari tong sampah</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="restore-password">Password</Label>
              <Input
                id="restore-password"
                type="password"
                value={restorePassword}
                onChange={(e) => setRestorePassword(e.target.value)}
                placeholder="Masukkan password Anda"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRestoreDialogOpen(false)}>
              Batal
            </Button>
            <Button onClick={confirmRestore}>Memungut</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

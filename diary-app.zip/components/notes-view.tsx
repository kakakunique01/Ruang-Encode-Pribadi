"use client"

import { useState, useEffect } from "react"
import type { User } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Label } from "@/components/ui/label"
import { Plus, Trash2 } from "lucide-react"
import { type Note, getNotes, addNote, updateNote, deleteNote } from "@/lib/storage"
import { tokenizeText } from "@/lib/crypto"

interface NotesViewProps {
  user: User
  selectedNoteId?: string
  onNoteChange?: () => void
}

export function NotesView({ user, selectedNoteId, onNoteChange }: NotesViewProps) {
  const [notes, setNotes] = useState<Note[]>([])
  const [selectedNote, setSelectedNote] = useState<Note | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [newTitle, setNewTitle] = useState("")
  const [editContent, setEditContent] = useState("")

  useEffect(() => {
    if (!selectedNote || !editContent) return

    const timer = setTimeout(() => {
      if (editContent !== selectedNote.content) {
        updateNote(user.username, selectedNote.id, { content: editContent })
        loadNotes()
        onNoteChange?.()
      }
    }, 1000)

    return () => clearTimeout(timer)
  }, [editContent, selectedNote, user])

  useEffect(() => {
    loadNotes()
  }, [user.username])

  useEffect(() => {
    if (selectedNoteId) {
      const note = notes.find((n) => n.id === selectedNoteId)
      if (note) {
        setSelectedNote(note)
        setEditContent(note.content)
      }
    }
  }, [selectedNoteId, notes])

  const loadNotes = () => {
    const userNotes = getNotes(user.username)
    setNotes(userNotes)
  }

  const handleAddNote = () => {
    if (newTitle.trim()) {
      const now = new Date().toISOString()
      const newNote = addNote(user.username, {
        title: newTitle,
        content: "",
        createdAt: now,
        encryptionLevel: user.level,
      })
      loadNotes()
      setIsAddDialogOpen(false)
      setNewTitle("")
      if (newNote) {
        setSelectedNote(newNote)
        setEditContent("")
      }
      onNoteChange?.()
    }
  }

  const handleDeleteNote = () => {
    if (selectedNote) {
      deleteNote(user.username, selectedNote.id)
      loadNotes()
      setSelectedNote(null)
      setEditContent("")
      setIsDeleteDialogOpen(false)
      onNoteChange?.()
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("id-ID", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    })
  }

  const renderAksara = (content: string) => {
    const tokens = tokenizeText(content, user.level)
    console.log("[v0] renderAksara - user.level:", user.level, "tokens:", tokens)

    return (
      <div className="text-base leading-relaxed whitespace-pre-wrap break-words">
        {tokens.map((token, index) => {
          if (token.imageUrl) {
            return (
              <span key={index} className="inline-block align-middle mx-0.5">
                <img
                  src={token.imageUrl || "/placeholder.svg"}
                  alt={token.text}
                  className="inline-block h-6 w-auto"
                  title={`${token.text} (Level ${token.level})`}
                />
              </span>
            )
          }
          return <span key={index}>{token.text}</span>
        })}
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col h-screen">
      {selectedNote ? (
        <div className="flex-1 flex flex-col p-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">{selectedNote.title}</h1>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>Dibuat: {formatDate(selectedNote.createdAt)}</p>
                <p>Terakhir diubah: {formatDate(selectedNote.updatedAt)}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Tambah Halaman
              </Button>
              <Button variant="destructive" onClick={() => setIsDeleteDialogOpen(true)}>
                <Trash2 className="w-4 h-4 mr-2" />
                Hapus
              </Button>
            </div>
          </div>

          <div className="flex-1 flex flex-col gap-4">
            <div className="flex-1">
              <Textarea
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                placeholder="Mulai menulis catatan Anda..."
                className="h-full resize-none text-base leading-relaxed"
              />
            </div>

            {editContent && (
              <div className="border rounded-lg p-4 bg-muted/30 min-h-[200px]">
                <div className="text-xs text-muted-foreground mb-2 font-semibold">
                  Preview Aksara (Level {user.level}):
                </div>
                {renderAksara(editContent)}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold text-foreground">
              Selamat Datang Wahai {user.displayName || user.username}
            </h2>
            <p className="text-muted-foreground">Pilih catatan dari sidebar atau buat halaman baru</p>
            <Button onClick={() => setIsAddDialogOpen(true)} size="lg">
              <Plus className="w-4 h-4 mr-2" />
              Buat Halaman Pertama
            </Button>
          </div>
        </div>
      )}

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tambah Halaman Baru</DialogTitle>
            <DialogDescription>Buat catatan baru. Tanggal akan dibuat otomatis.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Judul</Label>
              <Input
                id="title"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Judul catatan"
                onKeyDown={(e) => e.key === "Enter" && handleAddNote()}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Batal
            </Button>
            <Button onClick={handleAddNote}>Buat</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Yakin nih mau dibuang?</AlertDialogTitle>
            <AlertDialogDescription>
              Catatan akan dipindahkan ke Tong Sampah dan akan dihapus permanen setelah 7 hari.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteNote}>Ya, Buang</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

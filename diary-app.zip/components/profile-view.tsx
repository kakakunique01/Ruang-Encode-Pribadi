"use client"

import { useState } from "react"
import { type User, updateUserPassword, updateUsername, updateDisplayName } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ENCRYPTION_LEVELS } from "@/lib/types"

interface ProfileViewProps {
  user: User
}

export function ProfileView({ user }: ProfileViewProps) {
  const [oldPassword, setOldPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [newUsername, setNewUsername] = useState(user.username)
  const [displayName, setDisplayName] = useState(user.displayName || user.username)
  const [message, setMessage] = useState("")

  const handleUpdateDisplayName = () => {
    setMessage("")
    if (displayName.trim() === "") {
      setMessage("Nama tidak boleh kosong!")
      return
    }

    const success = updateDisplayName(user.username, displayName)
    if (success) {
      setMessage("Nama berhasil diubah!")
      setTimeout(() => {
        window.location.reload()
      }, 1500)
    } else {
      setMessage("Gagal mengubah nama!")
    }
  }

  const handleChangeUsername = () => {
    setMessage("")

    if (user.role !== "kang") {
      setMessage("Hanya Kang Sampah yang bisa mengubah username!")
      return
    }

    if (newUsername.trim() === "") {
      setMessage("Username tidak boleh kosong!")
      return
    }

    const success = updateUsername(user.username, newUsername, user.password)
    if (success) {
      setMessage("Username berhasil diubah! Silakan login ulang.")
      setTimeout(() => {
        window.location.reload()
      }, 1500)
    } else {
      setMessage("Username sudah digunakan atau terjadi kesalahan!")
    }
  }

  const handleChangePassword = () => {
    setMessage("")

    if (oldPassword !== user.password) {
      setMessage("Password lama salah!")
      return
    }

    if (newPassword !== confirmPassword) {
      setMessage("Password baru tidak cocok!")
      return
    }

    if (newPassword.trim() === "") {
      setMessage("Password baru tidak boleh kosong!")
      return
    }

    const success = updateUserPassword(user.username, oldPassword, newPassword)
    if (success) {
      setMessage("Password berhasil diubah!")
      setOldPassword("")
      setNewPassword("")
      setConfirmPassword("")
      setTimeout(() => {
        window.location.reload()
      }, 1500)
    } else {
      setMessage("Gagal mengubah password!")
    }
  }

  const getLevelBadge = () => {
    switch (user.role) {
      case "admin":
        return <Badge variant="default">Mutlak</Badge>
      case "user":
        return <Badge variant="secondary">Tertentu</Badge>
      case "kang":
        return <Badge variant="outline">Kang Mas</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  return (
    <div className="p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <h2 className="text-3xl font-bold text-foreground">Profil</h2>
          <p className="text-muted-foreground mt-1">Kelola informasi akun Anda</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Informasi Akun</CardTitle>
            <CardDescription>Detail akun Anda saat ini</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-muted-foreground">Username</span>
              <span className="font-medium">{user.username}</span>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-muted-foreground">Level</span>
              {getLevelBadge()}
            </div>
            {user.level !== undefined && (
              <div className="flex justify-between items-center py-3">
                <span className="text-muted-foreground">Level Enkripsi</span>
                <span className="text-sm text-muted-foreground">{ENCRYPTION_LEVELS[user.level]}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {user.role === "kang" && (
          <Card>
            <CardHeader>
              <CardTitle>Ganti Username</CardTitle>
              <CardDescription>Ubah username akun Anda</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new-username">Username Baru</Label>
                <Input
                  id="new-username"
                  type="text"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  placeholder="Masukkan username baru"
                />
              </div>
              <Button onClick={handleChangeUsername} className="w-full">
                Ubah Username
              </Button>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Ganti Nama</CardTitle>
            <CardDescription>Ubah nama tampilan Anda (bukan username)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="display-name">Nama</Label>
              <Input
                id="display-name"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Masukkan nama Anda"
              />
            </div>
            <Button onClick={handleUpdateDisplayName} className="w-full">
              Ubah Nama
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ganti Password</CardTitle>
            <CardDescription>Perbarui password akun Anda untuk keamanan lebih baik</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="old-password">Password Lama</Label>
              <Input
                id="old-password"
                type="password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                placeholder="Masukkan password lama"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">Password Baru</Label>
              <Input
                id="new-password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Masukkan password baru"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-password">Konfirmasi Password Baru</Label>
              <Input
                id="confirm-password"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Masukkan ulang password baru"
              />
            </div>
            {message && (
              <div
                className={`text-sm p-3 rounded-md ${
                  message.includes("berhasil") ? "bg-green-500/10 text-green-600" : "bg-destructive/10 text-destructive"
                }`}
              >
                {message}
              </div>
            )}
            <Button onClick={handleChangePassword} className="w-full">
              Ubah Password
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

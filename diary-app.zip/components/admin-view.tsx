"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { UserPlus, Pencil } from "lucide-react"
import { type User, getAllUsers, addUser, updateUserLevel } from "@/lib/auth"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function AdminView() {
  const [users, setUsers] = useState<User[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [newUsername, setNewUsername] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [newLevel, setNewLevel] = useState<number>(0)
  const [newDisplayName, setNewDisplayName] = useState("")

  useEffect(() => {
    loadUsers()
  }, [])

  const loadUsers = () => {
    const allUsers = getAllUsers().filter((u) => u.role === "user")
    setUsers(allUsers)
  }

  const handleAddUser = () => {
    if (newUsername.trim() && newPassword.trim()) {
      const success = addUser(newUsername, newPassword, "user", newLevel, newDisplayName || newUsername)
      if (success) {
        loadUsers()
        setIsAddDialogOpen(false)
        setNewUsername("")
        setNewPassword("")
        setNewLevel(0)
        setNewDisplayName("")
      } else {
        alert("Username sudah ada!")
      }
    }
  }

  const handleEditUser = () => {
    if (selectedUser) {
      updateUserLevel(selectedUser.username, "user", newPassword, newLevel)
      loadUsers()
      setIsEditDialogOpen(false)
      setSelectedUser(null)
      setNewPassword("")
    }
  }

  const openEditDialog = (user: User) => {
    setSelectedUser(user)
    setNewLevel(user.level === "pro" ? 99 : Number(user.level))
    setNewPassword("")
    setIsEditDialogOpen(true)
  }

  const getLevelLabel = (level: number | "pro") => {
    if (level === "pro" || level === 99) return "Pro"
    return `Level ${level}`
  }

  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-foreground">Admin Kuasa</h2>
            <p className="text-muted-foreground mt-1">Kelola akun pengguna umum</p>
          </div>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <UserPlus className="w-4 h-4 mr-2" />
            Tambah Akun
          </Button>
        </div>

        <div className="space-y-4">
          {users.map((user) => (
            <Card key={user.username}>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>{user.displayName || user.username}</CardTitle>
                  <CardDescription>Level: {getLevelLabel(user.level)} | Badge: Tertentu</CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => openEditDialog(user)}>
                  <Pencil className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              </CardHeader>
            </Card>
          ))}
        </div>

        {users.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground">Belum ada akun umum terdaftar</p>
          </div>
        )}
      </div>

      {/* Add User Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tambah Akun Baru</DialogTitle>
            <DialogDescription>Buat akun pengguna baru</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new-username">Username</Label>
              <Input
                id="new-username"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="Username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-displayname">Nama</Label>
              <Input
                id="new-displayname"
                value={newDisplayName}
                onChange={(e) => setNewDisplayName(e.target.value)}
                placeholder="Nama (opsional)"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">Password</Label>
              <Input
                id="new-password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Password"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-level">Level Enkripsi</Label>
              <Select value={String(newLevel)} onValueChange={(v) => setNewLevel(Number(v))}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Level 0</SelectItem>
                  <SelectItem value="1">Level 1</SelectItem>
                  <SelectItem value="2">Level 2</SelectItem>
                  <SelectItem value="3">Level 3</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Batal
            </Button>
            <Button onClick={handleAddUser}>Tambah</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Akun</DialogTitle>
            <DialogDescription>Ubah level dan password pengguna</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Username</Label>
              <Input value={selectedUser?.username || ""} disabled />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-password">Password Baru</Label>
              <Input
                id="edit-password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Password baru (kosongkan jika tidak diubah)"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-level">Level Enkripsi</Label>
              <Select value={String(newLevel)} onValueChange={(v) => setNewLevel(Number(v))}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Level 0</SelectItem>
                  <SelectItem value="1">Level 1</SelectItem>
                  <SelectItem value="2">Level 2</SelectItem>
                  <SelectItem value="3">Level 3</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Batal
            </Button>
            <Button onClick={handleEditUser}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

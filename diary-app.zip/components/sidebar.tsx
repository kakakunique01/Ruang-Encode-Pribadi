"use client"

import type { User } from "@/lib/auth"
import type { ViewType } from "@/components/dashboard"
import { Button } from "@/components/ui/button"
import { FileText, UserCircle, Trash2, LogOut, Shield, Recycle } from "lucide-react"
import { cn } from "@/lib/utils"
import { getNotes } from "@/lib/storage"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useState } from "react"

interface SidebarProps {
  user: User
  currentView: ViewType
  onViewChange: (view: ViewType) => void
  onLogout: () => void
  selectedNoteId?: string
  onSelectNote?: (noteId: string) => void
}

export function Sidebar({ user, currentView, onViewChange, onLogout, selectedNoteId, onSelectNote }: SidebarProps) {
  const [showLogoutDialog, setShowLogoutDialog] = useState(false)

  const menuItems = [
    ...(user.role !== "kang" ? [{ icon: FileText, label: "Catatan", view: "notes" as ViewType }] : []),
    { icon: UserCircle, label: "Profil", view: "profile" as ViewType },
    ...(user.role !== "kang" ? [{ icon: Trash2, label: "Tong Sampah", view: "trash" as ViewType }] : []),
    ...(user.role === "admin" ? [{ icon: Shield, label: "Admin Kuasa", view: "admin" as ViewType }] : []),
    ...(user.role === "kang" ? [{ icon: Recycle, label: "Tong Sampah", view: "kang-trash" as ViewType }] : []),
  ]

  const notes = currentView === "notes" && user.role !== "kang" ? getNotes(user.username) : []
  const sortedNotes = [...notes].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())

  const handleLogout = () => {
    setShowLogoutDialog(false)
    onLogout()
  }

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-xl font-bold text-sidebar-foreground">Ruang Encode</h1>
        <p className="text-sm text-sidebar-foreground/60 mt-1">{user.username}</p>
      </div>

      <nav className="p-4 space-y-2">
        {menuItems.map((item) => (
          <Button
            key={item.view}
            variant={currentView === item.view ? "secondary" : "ghost"}
            className={cn(
              "w-full justify-start",
              currentView === item.view && "bg-sidebar-accent text-sidebar-accent-foreground",
            )}
            onClick={() => onViewChange(item.view)}
          >
            <item.icon className="w-4 h-4 mr-3" />
            {item.label}
          </Button>
        ))}
      </nav>

      {currentView === "notes" && sortedNotes.length > 0 && (
        <>
          <div className="mx-4 border-t border-sidebar-border" />
          <div className="flex-1 overflow-y-auto px-4 py-2">
            {sortedNotes.map((note) => (
              <Button
                key={note.id}
                variant="ghost"
                className={cn(
                  "w-full justify-start text-left mb-1 h-auto py-2 px-3",
                  selectedNoteId === note.id && "bg-sidebar-accent text-sidebar-accent-foreground",
                )}
                onClick={() => onSelectNote?.(note.id)}
              >
                <span className="truncate text-sm">{note.title}</span>
              </Button>
            ))}
          </div>
        </>
      )}

      <div className="mt-auto p-4 border-t border-sidebar-border">
        <Button
          variant="ghost"
          className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={() => setShowLogoutDialog(true)}
        >
          <LogOut className="w-4 h-4 mr-3" />
          Keluar
        </Button>
      </div>

      <AlertDialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Yakin mau keluar?</AlertDialogTitle>
            <AlertDialogDescription>
              Anda akan keluar dari akun {user.username}. Pastikan semua perubahan sudah tersimpan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleLogout} className="bg-destructive hover:bg-destructive/90">
              Ya, Keluar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </aside>
  )
}

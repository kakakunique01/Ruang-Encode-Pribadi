"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Trash2 } from "lucide-react"
import { type Note, getAllPermanentlyDeleted, permanentlyDestroyNote } from "@/lib/storage"

export function KangTrashView() {
  const [permanentTrash, setPermanentTrash] = useState<(Note & { owner: string })[]>([])
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedNote, setSelectedNote] = useState<(Note & { owner: string }) | null>(null)

  useEffect(() => {
    loadPermanentTrash()
  }, [])

  const loadPermanentTrash = () => {
    const trash = getAllPermanentlyDeleted()
    setPermanentTrash(trash)
  }

  const handlePermanentDestroy = (note: Note & { owner: string }) => {
    setSelectedNote(note)
    setIsDeleteDialogOpen(true)
  }

  const confirmDestroy = () => {
    if (selectedNote) {
      permanentlyDestroyNote(selectedNote.id)
      loadPermanentTrash()
      setIsDeleteDialogOpen(false)
      setSelectedNote(null)
    }
  }

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground">Tong Sampah Permanen (TPA)</h2>
          <p className="text-muted-foreground mt-1">
            Semua catatan yang telah dihapus permanen dari semua akun. Klik hapus untuk memusnahkan selamanya.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {permanentTrash.map((note) => (
            <Card key={`${note.owner}-${note.id}`} className="opacity-75 hover:opacity-100 transition-opacity">
              <CardHeader>
                <CardTitle className="text-lg line-clamp-1">{note.title}</CardTitle>
                <p className="text-sm text-muted-foreground">Dibuat: {note.createdAt}</p>
                <p className="text-xs text-primary">Pemilik: {note.owner}</p>
              </CardHeader>
              <CardContent>
                <div className="font-cryptic text-sm mb-4 h-20 overflow-hidden opacity-50">{note.content}</div>
                <Button size="sm" variant="destructive" onClick={() => handlePermanentDestroy(note)} className="w-full">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Hapus Permanen
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {permanentTrash.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground">Belum ada sampah permanen</p>
          </div>
        )}
      </div>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Hapus Permanen?</DialogTitle>
            <DialogDescription>
              Catatan ini akan dihapus selamanya dan tidak bisa dikembalikan. Yakin ingin memusnahkan catatan ini?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Batal
            </Button>
            <Button variant="destructive" onClick={confirmDestroy}>
              Ya, Hapus Permanen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
